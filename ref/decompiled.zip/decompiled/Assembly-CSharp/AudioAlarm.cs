public class AudioAlarm : IOEntity
{
}
