public enum AntiHackType
{
	None,
	NoClip,
	SpeedHack,
	FlyHack,
	ProjectileHack,
	MeleeHack,
	EyeHack,
	AttackHack,
	ReloadHack,
	CooldownHack,
	InsideTerrain,
	InsideGeometry,
	EffectHack,
	Ticks
}
