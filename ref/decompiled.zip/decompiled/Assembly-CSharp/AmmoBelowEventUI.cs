public class AmmoBelowEventUI : BaseEventUI
{
}
