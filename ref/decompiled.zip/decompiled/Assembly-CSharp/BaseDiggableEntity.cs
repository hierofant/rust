using System.Collections.Generic;
using System.Linq;
using Facepunch;
using Network;
using Oxide.Core;
using UnityEngine;

public class BaseDiggableEntity : BaseCombatEntity
{
	public bool RequiresShovel;

	public Vector3 DropOffset;

	public Vector3 DropVelocity;

	public int RequiredDigCount = 3;

	public bool DestroyOnDug = true;

	[Header("Loot")]
	public List<DiggableEntityLoot> LootLists = new List<DiggableEntityLoot>();

	public int digsRemaining;

	public override bool ValidateMeleeColliderAntihack => false;

	public override bool OnRpcMessage(BasePlayer player, uint rpc, Message msg)
	{
		using (TimeWarning.New("BaseDiggableEntity.OnRpcMessage"))
		{
		}
		return base.OnRpcMessage(player, rpc, msg);
	}

	public override void ServerInit()
	{
		base.ServerInit();
		digsRemaining = RequiredDigCount;
		_maxHealth = RequiredDigCount;
	}

	public override void Hurt(HitInfo info)
	{
		if (!(info.InitiatorPlayer == null) && (!RequiresShovel || (!(info.Weapon == null) && info.Weapon is Shovel)) && info.damageTypes.IsMeleeType())
		{
			Dig(info.InitiatorPlayer);
		}
	}

	public virtual void Dig(BasePlayer player)
	{
		if (Interface.CallHook("OnPlayerDig", player, this) != null)
		{
			return;
		}
		if (digsRemaining == RequiredDigCount)
		{
			OnFirstDig(player);
		}
		ClientRPC(RpcTarget.NetworkGroup("RPC_OnDig"), RequiredDigCount - digsRemaining, RequiredDigCount);
		digsRemaining--;
		base.health = digsRemaining;
		SendNetworkUpdate();
		OnSingleDig(player);
		if (digsRemaining <= 0)
		{
			OnFullyDug(player);
			if (DestroyOnDug)
			{
				Kill();
			}
		}
	}

	public virtual void OnFirstDig(BasePlayer player)
	{
	}

	public virtual void OnSingleDig(BasePlayer player)
	{
	}

	public virtual void OnFullyDug(BasePlayer player)
	{
		if (Interface.CallHook("OnPlayerDigComplete", player, this) == null)
		{
			SpawnLootListItem(player);
		}
	}

	public BaseEntity SpawnLootListItem(BasePlayer player)
	{
		DiggableEntityLoot.ItemEntry? item = GetItem(base.transform.position);
		if (!item.HasValue || !item.HasValue)
		{
			return null;
		}
		Item item2 = ItemManager.Create(item.Value.Item, UnityEngine.Random.Range(item.Value.Min, item.Value.Max + 1), item.Value.Skin, isServerSide: true, 0uL);
		if (item.Value.Owner.HasValue)
		{
			ItemOwnershipShare value = item.Value.Owner.Value;
			item2.AddItemOwnership(value.username, value.reason, value.amount);
		}
		item2.AddItemOwnership(player, ItemOwnershipPhrases.MetalDetector);
		if (item.Value.Condition.HasValue)
		{
			item2.condition = item.Value.Condition.Value;
		}
		DroppedItem droppedItem = null;
		if (item2 != null)
		{
			if (item2.hasCondition && !item.Value.Condition.HasValue)
			{
				item2.condition = UnityEngine.Random.Range(item2.info.condition.foundCondition.fractionMin, item2.info.condition.foundCondition.fractionMax) * item2.info.condition.max;
			}
			droppedItem = item2.Drop(base.transform.position + DropOffset, DropVelocity) as DroppedItem;
			if (droppedItem != null)
			{
				droppedItem.NeverCombine = true;
				droppedItem.SetAngularVelocity(new Vector3(UnityEngine.Random.Range(-1f, 1f), UnityEngine.Random.Range(-1f, 1f), UnityEngine.Random.Range(-1f, 1f)) * 720f);
			}
			if (item.Value.UID.HasValue)
			{
				BuriedItems.Instance.UnregisterItem(item.Value.UID.Value);
			}
		}
		return droppedItem;
	}

	private DiggableEntityLoot.ItemEntry? GetItem(Vector3 digWorldPos)
	{
		if (LootLists == null)
		{
			return null;
		}
		List<DiggableEntityLoot.ItemEntry> obj = Pool.Get<List<DiggableEntityLoot.ItemEntry>>();
		obj.Clear();
		foreach (DiggableEntityLoot lootList in LootLists)
		{
			if (lootList.VerifyLootListForWorldPosition(digWorldPos))
			{
				obj.AddRange(lootList.GetItems());
			}
		}
		if ((bool)BuriedItems.Instance)
		{
			BuriedItems.Instance.AddItems(obj, digWorldPos);
		}
		DiggableEntityLoot.ItemEntry? result = null;
		if (obj.Count != 0)
		{
			int num = obj.Sum((DiggableEntityLoot.ItemEntry x) => x.Weight);
			int num2 = UnityEngine.Random.Range(0, num);
			for (int i = 0; i < obj.Count; i++)
			{
				result = obj[i];
				if (result.HasValue)
				{
					num -= result.Value.Weight;
					if (num2 >= num)
					{
						break;
					}
				}
			}
		}
		Pool.FreeUnmanaged(ref obj);
		return result;
	}
}
