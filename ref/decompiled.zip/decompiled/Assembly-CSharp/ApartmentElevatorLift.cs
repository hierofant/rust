public class ApartmentElevatorLift : ElevatorLiftStatic
{
}
