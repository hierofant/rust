public class ArcadeTennisPaddle : ArcadeEntity
{
}
