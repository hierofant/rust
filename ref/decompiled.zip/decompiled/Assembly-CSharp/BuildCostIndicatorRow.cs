public class BuildCostIndicatorRow : CostIndicatorRow
{
}
