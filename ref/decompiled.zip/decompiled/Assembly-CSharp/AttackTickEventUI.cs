public class AttackTickEventUI : BaseEventUI
{
}
