public class AuroraEffect : WeatherEffect
{
}
