public static class BatchingToggleEx
{
}
