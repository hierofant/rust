using Development.Attributes;
using UnityEngine;

[ResetStaticFields]
public class Buttons
{
	public class ConButton : ConsoleSystem.IConsoleButton
	{
		private int frame;

		private TimeSince _timePressed;

		public bool IsDown { get; set; }

		public TimeSince TimePressed
		{
			get
			{
				if (!IsDown)
				{
					return 0f;
				}
				return _timePressed;
			}
		}

		public bool JustPressed
		{
			get
			{
				if (IsDown)
				{
					return frame == Time.frameCount;
				}
				return false;
			}
		}

		public bool JustReleased
		{
			get
			{
				if (!IsDown)
				{
					return frame == Time.frameCount;
				}
				return false;
			}
		}

		public bool IsPressed
		{
			get
			{
				return IsDown;
			}
			set
			{
				if (value != IsDown)
				{
					IsDown = value;
					frame = Time.frameCount;
					_timePressed = 0f;
				}
			}
		}

		public void Reset()
		{
			_timePressed = default(TimeSince);
			IsDown = false;
			frame = 0;
		}

		public void Call(ConsoleSystem.Arg arg)
		{
		}
	}
}
