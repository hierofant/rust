#define UNITY_ASSERTIONS
using System;
using System.Collections;
using System.Collections.Generic;
using ConVar;
using Development.Attributes;
using Facepunch;
using Network;
using Oxide.Core;
using ProtoBuf;
using Rust;
using Rust.Ai.Gen2;
using Rust.Ai.Gen2.Nav;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEngine.Serialization;

public class BaseVehicle : BaseMountable, VehicleSpawner.IVehicleSpawnUser
{
	public enum DismountStyle
	{
		Closest,
		Ordered
	}

	public enum NpcVisibilityCategory
	{
		LikeNormalPlayer,
		QuiteObious,
		VeryObvious
	}

	[Serializable]
	public class MountPointInfo
	{
		public bool isDriver;

		public Vector3 pos;

		public Vector3 rot;

		public string bone = "";

		public GameObjectRef prefab;

		[NonSerialized]
		[HideInInspector]
		public BaseMountable mountable;
	}

	public enum RagdollMode
	{
		Collide,
		FallThrough
	}

	public enum ClippingCheckMode
	{
		OnMountOnly,
		Always
	}

	public enum ClippingCheckAiMode
	{
		All,
		PlayerOnly
	}

	public readonly struct Enumerable : IEnumerable<MountPointInfo>, IEnumerable
	{
		private readonly BaseVehicle _vehicle;

		public Enumerable(BaseVehicle vehicle)
		{
			if (vehicle == null)
			{
				throw new ArgumentNullException("vehicle");
			}
			_vehicle = vehicle;
		}

		public Enumerator GetEnumerator()
		{
			return new Enumerator(_vehicle);
		}

		IEnumerator<MountPointInfo> IEnumerable<MountPointInfo>.GetEnumerator()
		{
			return GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}

	public struct Enumerator : IEnumerator<MountPointInfo>, IEnumerator, IDisposable
	{
		private enum State
		{
			Direct,
			EnterChild,
			EnumerateChild,
			Finished
		}

		private class Box : Facepunch.Pool.IPooled
		{
			public Enumerator Value;

			public void EnterPool()
			{
				Value = default(Enumerator);
			}

			public void LeavePool()
			{
				Value = default(Enumerator);
			}
		}

		private readonly BaseVehicle _vehicle;

		private State _state;

		private int _index;

		private int _childIndex;

		private Box _enumerator;

		public MountPointInfo Current { get; private set; }

		object IEnumerator.Current => Current;

		public Enumerator(BaseVehicle vehicle)
		{
			if (vehicle == null)
			{
				throw new ArgumentNullException("vehicle");
			}
			_vehicle = vehicle;
			_state = State.Direct;
			_index = -1;
			_childIndex = -1;
			_enumerator = null;
			Current = null;
		}

		public bool MoveNext()
		{
			Current = null;
			switch (_state)
			{
			case State.Direct:
				_index++;
				if (_index >= _vehicle.mountPoints.Count)
				{
					_state = State.EnterChild;
					goto case State.EnterChild;
				}
				Current = _vehicle.mountPoints[_index];
				return true;
			case State.EnterChild:
				do
				{
					_childIndex++;
				}
				while (_childIndex < _vehicle.childVehicles.Count && _vehicle.childVehicles[_childIndex] == null);
				if (_childIndex >= _vehicle.childVehicles.Count)
				{
					_state = State.Finished;
					return false;
				}
				_enumerator = Facepunch.Pool.Get<Box>();
				_enumerator.Value = _vehicle.childVehicles[_childIndex].allMountPoints.GetEnumerator();
				_state = State.EnumerateChild;
				goto case State.EnumerateChild;
			case State.EnumerateChild:
				if (_enumerator.Value.MoveNext())
				{
					Current = _enumerator.Value.Current;
					return true;
				}
				_enumerator.Value.Dispose();
				Facepunch.Pool.Free(ref _enumerator);
				_state = State.EnterChild;
				goto case State.EnterChild;
			case State.Finished:
				return false;
			default:
				throw new NotSupportedException();
			}
		}

		public void Dispose()
		{
			if (_enumerator != null)
			{
				_enumerator.Value.Dispose();
				Facepunch.Pool.Free(ref _enumerator);
			}
		}

		public void Reset()
		{
			throw new NotSupportedException();
		}
	}

	private const float MIN_TIME_BETWEEN_PUSHES = 1f;

	public TimeSince timeSinceLastPush;

	private bool prevSleeping;

	private float nextCollisionFXTime;

	private CollisionDetectionMode savedCollisionDetectionMode;

	protected IAiInputProvider aiInputProvider;

	private Action AIDriverUpdateAction;

	private TimeSince timeSinceLastAIUpdate;

	private const float NavmeshMoveThreshold = 1f;

	private const float NavmeshStillTime = 1f;

	private Vector3 lastPosition;

	private Bounds lastNavmeshBuildBounds;

	private float lastNavmeshMoveTime;

	private bool navmeshRebuildPending;

	private ProtoBuf.BaseVehicle pendingLoad;

	public Queue<BasePlayer> recentDrivers = new Queue<BasePlayer>();

	public Action clearRecentDriverAction;

	public float safeAreaRadius;

	public Vector3 safeAreaOrigin;

	public float spawnTime = -1f;

	[Header("Base Vehicle")]
	[Tooltip("Check for vehicles clipping into our mount point as well as static stuff")]
	public bool checkVehicleClipping;

	[Tooltip("Exclude any problematic physics layers from colliding with this vehicle. Requires a DoPrepare to update")]
	public LayerMask excludeCollisionLayers;

	[Tooltip("Closest: Play will use the closest valid dismount point.\nOrdered: Player will use the first valid dismount point in the dismount array.")]
	public DismountStyle dismountStyle;

	public bool ignoreDamageFromOutside;

	public NpcVisibilityCategory npcVisibilityCategory;

	[Header("Base Vehicle - Mount Points")]
	public List<MountPointInfo> mountPoints;

	[Tooltip("Only set this if you want each BaseMountable to handle dismount without caring about the parent vehicle")]
	public bool childMountableHandleDismountPoints;

	public RagdollMode mountedPlayerRagdolls;

	public ClippingCheckMode clippingChecks;

	public ClippingCheckAiMode clippingAiChecks;

	[Header("Base Vehicle - Damage")]
	public DamageRenderer damageRenderer;

	[FormerlySerializedAs("explosionDamageMultiplier")]
	public float explosionForceMultiplier = 100f;

	public float explosionForceMax = 10000f;

	public const Flags Flag_OnlyOwnerEntry = Flags.Locked;

	public const Flags Flag_Headlights = Flags.Reserved5;

	public const Flags Flag_Stationary = Flags.Reserved7;

	public const Flags Flag_SeatsFull = Flags.Reserved11;

	public const Flags Flag_HasDriver = Flags.Reserved17;

	[Header("Base Vehicle - Priv")]
	public bool HasBuildingPrivilege;

	protected const Flags Flag_AnyMounted = Flags.InUse;

	private readonly List<BaseVehicle> childVehicles = new List<BaseVehicle>(0);

	public bool IsClient => base.isClient;

	public virtual bool AlwaysAllowBradleyTargeting => false;

	protected bool RecentlyPushed => (float)timeSinceLastPush < 1f;

	protected TimeSince TimeSinceLastAIUpdate => timeSinceLastAIUpdate;

	public override bool PositionTickFixedTime
	{
		protected get
		{
			return true;
		}
	}

	protected virtual bool CanSwapSeats => true;

	public bool IsMovingOrOn
	{
		get
		{
			if (!IsMoving())
			{
				return IsOn();
			}
			return true;
		}
	}

	public override float RealisticMass
	{
		get
		{
			if (rigidBody != null)
			{
				return rigidBody.mass;
			}
			return base.RealisticMass;
		}
	}

	public Enumerable allMountPoints => new Enumerable(this);

	public event Action<HitInfo> BeenAttacked;

	public event Action OnDismountAll;

	public event Action Died;

	public override bool OnRpcMessage(BasePlayer player, uint rpc, Message msg)
	{
		using (TimeWarning.New("BaseVehicle.OnRpcMessage"))
		{
			if (rpc == 2115395408 && player != null)
			{
				Assert.IsTrue(player.isServer, "SV_RPC Message is using a clientside player!");
				if (ConVar.Global.developer > 2)
				{
					Debug.Log("SV_RPCMessage: " + player?.ToString() + " - RPC_WantsPush");
				}
				using (TimeWarning.New("RPC_WantsPush"))
				{
					using (TimeWarning.New("Conditions"))
					{
						if (!RPC_Server.MaxDistance.Test(2115395408u, "RPC_WantsPush", this, player, 5f))
						{
							return true;
						}
					}
					try
					{
						using (TimeWarning.New("Call"))
						{
							RPCMessage rPCMessage = default(RPCMessage);
							rPCMessage.connection = msg.connection;
							rPCMessage.player = player;
							rPCMessage.read = msg.read;
							RPCMessage msg2 = rPCMessage;
							RPC_WantsPush(msg2);
						}
					}
					catch (Exception exception)
					{
						Debug.LogException(exception);
						player.Kick("RPC Error in RPC_WantsPush");
					}
				}
				return true;
			}
		}
		return base.OnRpcMessage(player, rpc, msg);
	}

	public virtual void AddAIDriver(IAiInputProvider provider)
	{
		if (aiInputProvider != null)
		{
			RemoveAIDriver();
		}
		aiInputProvider = provider;
		if (AIDriverUpdateAction == null)
		{
			AIDriverUpdateAction = AIDriverUpdateLoop;
		}
		aiInputProvider.OnAdd(this);
		timeSinceLastAIUpdate = 0f;
		if (!IsInvoking(AIDriverUpdateAction))
		{
			InvokeRandomized(AIDriverUpdateAction, 0f, 0f, 0.05f);
		}
	}

	public virtual void RemoveAIDriver(bool runCallbacks = true)
	{
		if (runCallbacks && aiInputProvider != null)
		{
			aiInputProvider.OnRemove(this);
			aiInputProvider = null;
		}
		if (IsInvoking(AIDriverUpdateAction))
		{
			CancelInvoke(AIDriverUpdateAction);
		}
		timeSinceLastAIUpdate = 0f;
	}

	public override void OnAttacked(HitInfo info)
	{
		if (IsSafe() && !info.damageTypes.Has(DamageType.Decay))
		{
			info.damageTypes.ScaleAll(0f);
		}
		this.BeenAttacked?.Invoke(info);
		base.OnAttacked(info);
	}

	public override void OnDied(HitInfo info)
	{
		this.Died?.Invoke();
		base.OnDied(info);
	}

	public override void PostServerLoad()
	{
		base.PostServerLoad();
		ClearOwnerEntry();
		CheckAndSpawnMountPoints();
		Invoke(DisableTransferProtectionIfEmpty, 0f);
	}

	public override void Save(SaveInfo info)
	{
		base.Save(info);
		if (!base.isServer || !info.forDisk)
		{
			return;
		}
		info.msg.baseVehicle = Facepunch.Pool.Get<ProtoBuf.BaseVehicle>();
		info.msg.baseVehicle.mountPoints = Facepunch.Pool.Get<List<ProtoBuf.BaseVehicle.MountPoint>>();
		for (int i = 0; i < mountPoints.Count; i++)
		{
			MountPointInfo mountPointInfo = mountPoints[i];
			if (!(mountPointInfo.mountable == null))
			{
				ProtoBuf.BaseVehicle.MountPoint mountPoint = Facepunch.Pool.Get<ProtoBuf.BaseVehicle.MountPoint>();
				mountPoint.index = i;
				mountPoint.mountableId = mountPointInfo.mountable.net.ID;
				info.msg.baseVehicle.mountPoints.Add(mountPoint);
			}
		}
	}

	public override void Load(LoadInfo info)
	{
		base.Load(info);
		if (base.isServer && info.fromDisk && info.msg.baseVehicle != null)
		{
			pendingLoad?.Dispose();
			pendingLoad = info.msg.baseVehicle;
			info.msg.baseVehicle = null;
		}
	}

	public override float GetNetworkTime()
	{
		return UnityEngine.Time.fixedTime;
	}

	public override float GetNetworkTime(in ThreadSafeTime time)
	{
		return time.FixedTime;
	}

	public void AIDriverUpdateLoop()
	{
		if (aiInputProvider == null)
		{
			RemoveAIDriver();
			return;
		}
		RunAIDriverTick();
		timeSinceLastAIUpdate = 0f;
	}

	public virtual void RunAIDriverTick()
	{
		if (aiInputProvider == null)
		{
			RemoveAIDriver();
		}
		else
		{
			aiInputProvider.OnTick(this, timeSinceLastAIUpdate);
		}
	}

	public override void VehicleFixedUpdate()
	{
		using (TimeWarning.New("BaseVehicle.VehicleFixedUpdate"))
		{
			base.VehicleFixedUpdate();
			if (clippingChecks == ClippingCheckMode.Always && AnyMounted())
			{
				bool flag = false;
				if (clippingAiChecks == ClippingCheckAiMode.PlayerOnly)
				{
					List<BasePlayer> obj = Facepunch.Pool.Get<List<BasePlayer>>();
					GetMountedPlayers(obj);
					foreach (BasePlayer item in obj)
					{
						if (!item.IsNpc)
						{
							flag = true;
							break;
						}
					}
					Facepunch.Pool.FreeUnmanaged(ref obj);
				}
				else if (clippingAiChecks == ClippingCheckAiMode.All)
				{
					flag = true;
				}
				if (flag && UnityEngine.Physics.CheckBox(base.transform.TransformPoint(bounds.center), bounds.extents, base.transform.rotation, GetClipCheckMask()))
				{
					CheckSeatsForClipping();
				}
			}
			if (rigidBody != null)
			{
				using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
				{
					flagsUpdateScope.Set(Flags.Reserved7, DetermineIfStationary());
				}
				bool flag2 = rigidBody.IsSleeping();
				if (prevSleeping && !flag2)
				{
					OnServerWake();
				}
				else if (!prevSleeping && flag2)
				{
					OnServerSleep();
				}
				prevSleeping = flag2;
			}
			if (OnlyOwnerAccessible() && safeAreaRadius != -1f && Vector3.Distance(base.transform.position, safeAreaOrigin) > safeAreaRadius)
			{
				ClearOwnerEntry();
			}
		}
	}

	protected override int GetClipCheckMask()
	{
		int num = (IsFlipped() ? 1218511105 : 1210122497);
		if (!ConVar.Physics.treecollision)
		{
			num &= -1073741825;
		}
		if (checkVehicleClipping)
		{
			num |= 0x2000;
		}
		return num;
	}

	protected virtual bool DetermineIfStationary()
	{
		if (rigidBody.IsSleeping())
		{
			return !AnyMounted();
		}
		return false;
	}

	public override Vector3 GetLocalVelocityServer()
	{
		if (rigidBody == null)
		{
			return Vector3.zero;
		}
		return rigidBody.linearVelocity;
	}

	public override Quaternion GetAngularVelocityServer()
	{
		if (rigidBody == null)
		{
			return Quaternion.identity;
		}
		return Quaternion.Euler(rigidBody.angularVelocity * 57.29578f);
	}

	public virtual int StartingFuelUnits()
	{
		IFuelSystem fuelSystem = GetFuelSystem();
		if (fuelSystem != null)
		{
			return Mathf.FloorToInt((float)fuelSystem.GetFuelCapacity() * 0.2f);
		}
		return 0;
	}

	public virtual bool IsSeatVisible(BaseMountable mountable, Vector3 eyePos, int mask = 1218511105)
	{
		if (!clippingAndVisChecks)
		{
			return true;
		}
		if (mountable == null)
		{
			return false;
		}
		Vector3 p = mountable.transform.position + base.transform.up * 0.15f;
		return GamePhysics.LineOfSight(eyePos, p, mask);
	}

	protected override bool IsSeatClipping(BaseMountable mountable, Vector3 startPos, float radius, int mask, Vector3 seatPos, Vector3 direction)
	{
		if (!checkVehicleClipping)
		{
			return base.IsSeatClipping(mountable, startPos, radius, mask, seatPos, direction);
		}
		List<Collider> obj = Facepunch.Pool.Get<List<Collider>>();
		if (clippingChecksLocation == ClippingCheckLocation.HeadOnly)
		{
			GamePhysics.OverlapSphere(startPos, radius, obj, mask);
		}
		else
		{
			Vector3 point = seatPos + direction * (radius + 0.05f);
			GamePhysics.OverlapCapsule(startPos, point, radius, obj, mask);
		}
		foreach (Collider item in obj)
		{
			BaseEntity baseEntity = GameObjectEx.ToBaseEntity(item);
			if ((!(baseEntity != null) || !baseEntity.isClient) && baseEntity != this && !EqualNetID(baseEntity) && mountable != this && !mountable.EqualNetID(baseEntity))
			{
				Facepunch.Pool.FreeUnmanaged(ref obj);
				return true;
			}
		}
		Facepunch.Pool.FreeUnmanaged(ref obj);
		return false;
	}

	public virtual void CheckSeatsForClipping()
	{
		foreach (MountPointInfo mountPoint in mountPoints)
		{
			BaseMountable mountable = mountPoint.mountable;
			if (!(mountable == null) && mountable.AnyMounted() && (clippingAiChecks != ClippingCheckAiMode.PlayerOnly || !(mountable.GetMounted() is HumanNPC)) && IsSeatClipping(mountable))
			{
				SeatClippedWorld(mountable);
			}
		}
	}

	public virtual void SeatClippedWorld(BaseMountable mountable)
	{
		mountable.DismountPlayer(mountable.GetMounted());
	}

	public override void MounteeTookDamage(BasePlayer mountee, HitInfo info)
	{
	}

	public override void DismountAllPlayers()
	{
		this.OnDismountAll?.Invoke();
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable != null)
			{
				allMountPoint.mountable.DismountAllPlayers();
			}
		}
	}

	public override void ServerInit()
	{
		base.ServerInit();
		clearRecentDriverAction = ClearRecentDriver;
		prevSleeping = false;
		if (rigidBody != null)
		{
			savedCollisionDetectionMode = rigidBody.collisionDetectionMode;
		}
		lastNavmeshBuildBounds = WorldSpaceBounds().ToBounds();
		lastPosition = base.transform.position;
		lastNavmeshMoveTime = UnityEngine.Time.time;
		navmeshRebuildPending = false;
		if (!AI.useUnityNavmesh)
		{
			RustNavigation.Instance.RebuildTilesInBounds(lastNavmeshBuildBounds);
		}
	}

	protected override void TransformChanged()
	{
		using (TimeWarning.New("BaseVehicle.TransformChanged"))
		{
			base.TransformChanged();
			if (!AI.useUnityNavmesh && Vector3.Distance(lastPosition, base.transform.position) > 1f)
			{
				lastPosition = base.transform.position;
				lastNavmeshMoveTime = UnityEngine.Time.time;
				if (!navmeshRebuildPending)
				{
					navmeshRebuildPending = true;
					InvokeRepeating(CheckNavmeshSettled, 1f, 0.25f);
				}
			}
		}
	}

	private void CheckNavmeshSettled()
	{
		using (TimeWarning.New("RustNavigation.CheckNavmeshSettled"))
		{
			if (!(UnityEngine.Time.time - lastNavmeshMoveTime < 1f))
			{
				CancelInvoke(CheckNavmeshSettled);
				navmeshRebuildPending = false;
				RebuildTile();
			}
		}
	}

	private void RebuildTile()
	{
		using (TimeWarning.New("BaseVehicle.RebuildTile"))
		{
			RustNavigation.Instance.RebuildTilesInBounds(lastNavmeshBuildBounds);
			lastNavmeshBuildBounds = WorldSpaceBounds().ToBounds();
			RustNavigation.Instance.RebuildTilesInBounds(lastNavmeshBuildBounds);
		}
	}

	public virtual void SpawnSubEntities()
	{
		CheckAndSpawnMountPoints();
	}

	public virtual bool AdminFixUp(int tier)
	{
		if (IsDead())
		{
			return false;
		}
		GetFuelSystem()?.FillFuel();
		SetHealth(MaxHealth());
		SendNetworkUpdate();
		return true;
	}

	private void OnPhysicsNeighbourChanged()
	{
		if (rigidBody != null)
		{
			rigidBody.WakeUp();
		}
	}

	private void CheckAndSpawnMountPoints()
	{
		if (pendingLoad?.mountPoints != null)
		{
			foreach (ProtoBuf.BaseVehicle.MountPoint mountPoint in pendingLoad.mountPoints)
			{
				EntityRef<BaseMountable> entityRef = new EntityRef<BaseMountable>(mountPoint.mountableId);
				if (!entityRef.IsValid(serverside: true))
				{
					Debug.LogError($"Loaded a mountpoint which doesn't exist: {mountPoint.index}", this);
					continue;
				}
				if (mountPoint.index < 0 || mountPoint.index >= mountPoints.Count)
				{
					Debug.LogError($"Loaded a mountpoint which has no info: {mountPoint.index}", this);
					entityRef.Get(serverside: true).Kill();
					continue;
				}
				MountPointInfo mountPointInfo = mountPoints[mountPoint.index];
				if (mountPointInfo.mountable != null)
				{
					Debug.LogError($"Loading a mountpoint after one was already set: {mountPoint.index}", this);
					mountPointInfo.mountable.Kill();
				}
				mountPointInfo.mountable = entityRef.Get(serverside: true);
				if (!mountPointInfo.mountable.enableSaving)
				{
					mountPointInfo.mountable.EnableSaving(wants: true);
				}
			}
		}
		pendingLoad?.Dispose();
		pendingLoad = null;
		for (int i = 0; i < mountPoints.Count; i++)
		{
			SpawnMountPoint(mountPoints[i], model);
		}
		UpdateMountFlags();
	}

	public override void Spawn()
	{
		base.Spawn();
		if (base.isServer && !Rust.Application.isLoadingSave)
		{
			SpawnSubEntities();
		}
	}

	public override void Hurt(HitInfo info)
	{
		DoExplosionForce(info);
		base.Hurt(info);
	}

	public void DoExplosionForce(HitInfo info)
	{
		if (!IsDead() && !IsTransferProtected() && !(rigidBody == null) && !rigidBody.isKinematic)
		{
			float num = info.damageTypes.Get(DamageType.Explosion) + info.damageTypes.Get(DamageType.AntiVehicle) * 0.5f;
			if (num > 3f)
			{
				float explosionForce = Mathf.Min(num * explosionForceMultiplier, explosionForceMax);
				rigidBody.AddExplosionForce(explosionForce, info.HitPositionWorld, 1f, 2.5f);
			}
		}
	}

	public int NumMounted()
	{
		if (!HasMountPoints())
		{
			if (!AnyMounted())
			{
				return 0;
			}
			return 1;
		}
		int num = 0;
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable != null && allMountPoint.mountable.GetMounted() != null)
			{
				num++;
			}
		}
		return num;
	}

	public virtual int MaxMounted()
	{
		if (!HasMountPoints())
		{
			return 1;
		}
		int num = 0;
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable != null)
			{
				num++;
			}
		}
		return num;
	}

	public bool HasDriverSlow()
	{
		if (aiInputProvider != null)
		{
			return true;
		}
		if (HasMountPoints())
		{
			if (!AnyMounted())
			{
				return false;
			}
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null && allMountPoint.isDriver && allMountPoint.mountable.AnyMounted())
				{
					return true;
				}
			}
			return false;
		}
		return base.AnyMounted();
	}

	public bool HasDriver()
	{
		return HasFlag(Flags.Reserved17);
	}

	public bool HasPassenger()
	{
		if (HasMountPoints())
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null && !allMountPoint.isDriver && allMountPoint.mountable.AnyMounted())
				{
					return true;
				}
			}
			return false;
		}
		return base.AnyMounted();
	}

	public bool IsPassenger(BasePlayer player)
	{
		if (HasMountPoints())
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null && !allMountPoint.isDriver)
				{
					BasePlayer mounted = allMountPoint.mountable.GetMounted();
					if (mounted != null && mounted == player)
					{
						return true;
					}
				}
			}
		}
		else
		{
			BasePlayer mounted2 = GetMounted();
			if (mounted2 != null)
			{
				return mounted2 == player;
			}
		}
		return false;
	}

	public BasePlayer GetDriver()
	{
		if (HasMountPoints())
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null && allMountPoint.isDriver)
				{
					BasePlayer mounted = allMountPoint.mountable.GetMounted();
					if (mounted != null)
					{
						return mounted;
					}
				}
			}
		}
		else
		{
			BasePlayer mounted2 = GetMounted();
			if (mounted2 != null)
			{
				return mounted2;
			}
		}
		return null;
	}

	public BasePlayer GetPassenger()
	{
		if (HasMountPoints())
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null && !allMountPoint.isDriver)
				{
					BasePlayer mounted = allMountPoint.mountable.GetMounted();
					if (mounted != null)
					{
						return mounted;
					}
				}
			}
		}
		else
		{
			BasePlayer mounted2 = GetMounted();
			if (mounted2 != null)
			{
				return mounted2;
			}
		}
		return null;
	}

	public void GetDrivers(List<BasePlayer> drivers)
	{
		if (HasMountPoints())
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null && allMountPoint.isDriver)
				{
					BasePlayer mounted = allMountPoint.mountable.GetMounted();
					if (mounted != null)
					{
						drivers.Add(mounted);
					}
				}
			}
			return;
		}
		BasePlayer mounted2 = GetMounted();
		if (mounted2 != null)
		{
			drivers.Add(mounted2);
		}
	}

	[PoolAnalyzerNonCaching]
	public void GetMountedPlayers(List<BasePlayer> players)
	{
		if (HasMountPoints())
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && allMountPoint.mountable != null)
				{
					BasePlayer mounted = allMountPoint.mountable.GetMounted();
					if (mounted != null)
					{
						players.Add(mounted);
					}
				}
			}
			return;
		}
		BasePlayer mounted2 = GetMounted();
		if (mounted2 != null)
		{
			players.Add(mounted2);
		}
	}

	public virtual BasePlayer GetPlayerDamageInitiator()
	{
		if (HasDriver())
		{
			return GetDriver();
		}
		if (recentDrivers.Count <= 0)
		{
			return null;
		}
		return recentDrivers.Peek();
	}

	public int GetPlayerSeat(BasePlayer player)
	{
		if (!HasMountPoints() && GetMounted() == player)
		{
			return 0;
		}
		int num = 0;
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable != null && allMountPoint.mountable.GetMounted() == player)
			{
				return num;
			}
			num++;
		}
		return -1;
	}

	public MountPointInfo GetPlayerSeatInfo(BasePlayer player)
	{
		if (!HasMountPoints())
		{
			return null;
		}
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable != null && allMountPoint.mountable.GetMounted() == player)
			{
				return allMountPoint;
			}
		}
		return null;
	}

	public bool IsVehicleMountPoint(BaseMountable bm)
	{
		if (!HasMountPoints() || bm == null)
		{
			return false;
		}
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable == bm)
			{
				return true;
			}
		}
		return false;
	}

	public virtual bool IsPlayerSeatSwapValid(BasePlayer player, int fromIndex, int toIndex, bool forcingRestrainedPlayer)
	{
		return !player.IsRestrained || forcingRestrainedPlayer;
	}

	public void SwapSeats(BasePlayer player, int targetSeat = -1, bool forcingRestrainedPlayer = false)
	{
		if (!HasMountPoints() || !CanSwapSeats)
		{
			return;
		}
		int currentSeatIndex = GetPlayerSeat(player);
		if (currentSeatIndex == -1)
		{
			return;
		}
		BaseMountable mountable = GetMountPoint(currentSeatIndex).mountable;
		BaseMountable baseMountable = null;
		if (targetSeat == -1)
		{
			int num = NumSwappableSeats();
			for (int i = 1; i <= num; i++)
			{
				int num2 = (currentSeatIndex + i) % num;
				MountPointInfo mountPoint = GetMountPoint(num2);
				if (IsValidSwap(mountPoint, num2))
				{
					baseMountable = mountPoint.mountable;
					break;
				}
			}
		}
		else
		{
			targetSeat = Mathf.Clamp(targetSeat, 0, NumSwappableSeats());
			MountPointInfo mountPoint2 = GetMountPoint(targetSeat);
			if (IsValidSwap(mountPoint2, targetSeat))
			{
				baseMountable = mountPoint2.mountable;
			}
		}
		if (baseMountable != null && baseMountable != mountable)
		{
			mountable.DismountPlayer(player, lite: true);
			baseMountable.MountPlayer(player);
			player.MarkSwapSeat();
		}
		bool IsValidSwap(MountPointInfo point, int toIndex)
		{
			if (point?.mountable != null && !point.mountable.AnyMounted() && point.mountable.CanSwapToThis(player) && !(point.isDriver && forcingRestrainedPlayer) && !IsSeatClipping(point.mountable) && IsSeatVisible(point.mountable, player.eyes.position))
			{
				return IsPlayerSeatSwapValid(player, currentSeatIndex, toIndex, forcingRestrainedPlayer);
			}
			return false;
		}
	}

	public virtual int NumSwappableSeats()
	{
		return MaxMounted();
	}

	public bool HasDriverMountPoints()
	{
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.isDriver)
			{
				return true;
			}
		}
		return false;
	}

	public bool OnlyOwnerAccessible()
	{
		return HasFlag(Flags.Locked);
	}

	public bool IsDespawnEligable()
	{
		if (spawnTime != -1f)
		{
			return spawnTime + 300f < UnityEngine.Time.realtimeSinceStartup;
		}
		return true;
	}

	public void SetupOwner(BasePlayer owner, Vector3 newSafeAreaOrigin, float newSafeAreaRadius)
	{
		if (owner != null)
		{
			creatorEntity = owner;
			base.OwnerID = owner.userID;
			bool b = true;
			BaseGameMode activeGameMode = BaseGameMode.GetActiveGameMode(base.isServer);
			if (activeGameMode != null && !activeGameMode.safeZone)
			{
				b = false;
			}
			using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
			{
				flagsUpdateScope.Set(Flags.Locked, b);
			}
			safeAreaRadius = newSafeAreaRadius;
			safeAreaOrigin = newSafeAreaOrigin;
			spawnTime = UnityEngine.Time.realtimeSinceStartup;
		}
	}

	public void ClearOwnerEntry()
	{
		creatorEntity = null;
		using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
		{
			flagsUpdateScope.Set(Flags.Locked, b: false);
		}
		safeAreaRadius = -1f;
		safeAreaOrigin = Vector3.zero;
	}

	private void DisableTransferProtectionIfEmpty()
	{
		if (!HasDriver())
		{
			DisableTransferProtection();
		}
	}

	public virtual IFuelSystem GetFuelSystem()
	{
		return null;
	}

	public bool IsSafe()
	{
		if (OnlyOwnerAccessible())
		{
			return Vector3.Distance(safeAreaOrigin, base.transform.position) <= safeAreaRadius;
		}
		return false;
	}

	public override void ScaleDamageForPlayer(BasePlayer player, HitInfo info)
	{
		if (IsSafe())
		{
			info.damageTypes.ScaleAll(0f);
		}
		base.ScaleDamageForPlayer(player, info);
	}

	public BaseMountable GetIdealMountPoint(Vector3 eyePos, Vector3 pos, BasePlayer playerFor = null)
	{
		if (playerFor == null)
		{
			return null;
		}
		if (!HasMountPoints())
		{
			return this;
		}
		BasePlayer basePlayer = creatorEntity as BasePlayer;
		bool flag = basePlayer != null;
		bool flag2 = flag && basePlayer.Team != null;
		bool flag3 = flag && playerFor == basePlayer;
		if (!flag3 && flag && OnlyOwnerAccessible() && playerFor != null && (playerFor.Team == null || !playerFor.Team.members.Contains(basePlayer.userID)))
		{
			return null;
		}
		BaseMountable result = null;
		float num = float.PositiveInfinity;
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable.AnyMounted() || (allMountPoint.isDriver && playerFor.IsRestrained))
			{
				continue;
			}
			float num2 = Vector3.Distance(allMountPoint.mountable.mountAnchor.position, pos);
			if (num2 > num)
			{
				continue;
			}
			if (IsSeatClipping(allMountPoint.mountable))
			{
				if (UnityEngine.Application.isEditor)
				{
					Debug.Log($"Skipping seat {allMountPoint.mountable} - it's clipping");
				}
			}
			else if (!IsSeatVisible(allMountPoint.mountable, eyePos))
			{
				if (UnityEngine.Application.isEditor)
				{
					Debug.Log($"Skipping seat {allMountPoint.mountable} - it's not visible");
				}
			}
			else if (!(OnlyOwnerAccessible() && flag3) || flag2 || allMountPoint.isDriver)
			{
				result = allMountPoint.mountable;
				num = num2;
			}
		}
		return result;
	}

	public virtual bool MountEligable(BasePlayer player)
	{
		if (OnlyOwnerAccessible() && creatorEntity != null && player != creatorEntity)
		{
			BasePlayer basePlayer = creatorEntity as BasePlayer;
			if (basePlayer != null && (basePlayer.Team == null || (basePlayer.Team != null && !basePlayer.Team.members.Contains(player.userID))))
			{
				return false;
			}
		}
		BaseVehicle baseVehicle = VehicleParent();
		if (baseVehicle != null)
		{
			return baseVehicle.MountEligable(player);
		}
		return true;
	}

	public int GetIndexFromSeat(BaseMountable seat)
	{
		int num = 0;
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (allMountPoint.mountable == seat)
			{
				return num;
			}
			num++;
		}
		return -1;
	}

	public virtual void PlayerMounted(BasePlayer player, BaseMountable seat)
	{
	}

	public virtual void PrePlayerDismount(BasePlayer player, BaseMountable seat)
	{
	}

	public virtual void PlayerDismounted(BasePlayer player, BaseMountable seat)
	{
		recentDrivers.Enqueue(player);
		if (!IsInvoking(clearRecentDriverAction))
		{
			Invoke(clearRecentDriverAction, 3f);
		}
	}

	public virtual GameObjectRef GetCollisionFX()
	{
		return null;
	}

	public void TryShowCollisionFX(Collision collision)
	{
		TryShowCollisionFX(collision, GetCollisionFX());
	}

	public void TryShowCollisionFX(Vector3 contactPoint)
	{
		TryShowCollisionFX(contactPoint, GetCollisionFX());
	}

	public void TryShowCollisionFX(Collision collision, GameObjectRef effectGO)
	{
		TryShowCollisionFX(collision.GetContact(0).point, effectGO);
	}

	public void TryShowCollisionFX(Vector3 contactPoint, GameObjectRef effectGO)
	{
		if (!(UnityEngine.Time.time < nextCollisionFXTime))
		{
			nextCollisionFXTime = UnityEngine.Time.time + 0.25f;
			if (effectGO != null && effectGO.isValid)
			{
				contactPoint += (base.transform.position - contactPoint) * 0.25f;
				Effect.server.Run(effectGO.resourcePath, contactPoint, base.transform.up);
			}
		}
	}

	public void SetToKinematic()
	{
		if (!(rigidBody == null) && !rigidBody.isKinematic)
		{
			savedCollisionDetectionMode = rigidBody.collisionDetectionMode;
			rigidBody.collisionDetectionMode = CollisionDetectionMode.Discrete;
			rigidBody.isKinematic = true;
		}
	}

	public void SetToNonKinematic()
	{
		if (!(rigidBody == null) && rigidBody.isKinematic)
		{
			rigidBody.isKinematic = false;
			rigidBody.collisionDetectionMode = savedCollisionDetectionMode;
		}
	}

	public override void UpdateMountFlags()
	{
		int num = NumMounted();
		using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
		{
			flagsUpdateScope.Set(Flags.InUse, num > 0);
			flagsUpdateScope.Set(Flags.Reserved11, num == MaxMounted());
			flagsUpdateScope.Set(Flags.Reserved17, HasDriverSlow());
		}
		BaseVehicle baseVehicle = VehicleParent();
		if (baseVehicle != null)
		{
			baseVehicle.UpdateMountFlags();
		}
	}

	public void ClearRecentDriver()
	{
		if (recentDrivers.Count > 0)
		{
			recentDrivers.Dequeue();
		}
		if (recentDrivers.Count > 0)
		{
			Invoke(clearRecentDriverAction, 3f);
		}
	}

	public override void AttemptMount(BasePlayer player, bool doMountChecks = true)
	{
		if (GetMounted() != null || !MountEligable(player))
		{
			return;
		}
		BaseMountable idealMountPointFor = GetIdealMountPointFor(player);
		if (!(idealMountPointFor == null))
		{
			if (idealMountPointFor == this)
			{
				base.AttemptMount(player, doMountChecks);
			}
			else
			{
				idealMountPointFor.AttemptMount(player, doMountChecks);
			}
			if (player.GetMountedVehicle() == this)
			{
				PlayerMounted(player, idealMountPointFor);
			}
		}
	}

	public BaseMountable GetIdealMountPointFor(BasePlayer player)
	{
		return GetIdealMountPoint(player.eyes.position, player.eyes.position + player.eyes.HeadForward() * 1f, player);
	}

	public override bool GetDismountPosition(BasePlayer player, out Vector3 res, bool silent = false)
	{
		using (TimeWarning.New("BaseVehicle.GetDismountPosition"))
		{
			BaseVehicle baseVehicle = VehicleParent();
			if (baseVehicle != null)
			{
				return baseVehicle.GetDismountPosition(player, out res, silent);
			}
			List<Transform> obj = Facepunch.Pool.Get<List<Transform>>();
			obj.AddRange(dismountPositions);
			if (dismountStyle == DismountStyle.Closest)
			{
				Vector3 comparePos = player.TriggerPoint();
				obj.Sort((Transform a, Transform b) => Vector3.SqrMagnitude(a.position - comparePos).CompareTo(Vector3.SqrMagnitude(b.position - comparePos)));
			}
			foreach (Transform item in obj)
			{
				if (ValidDismountPosition(player, item.transform.position) && (dismountStyle == DismountStyle.Ordered || dismountStyle == DismountStyle.Closest))
				{
					res = item.transform.position;
					Facepunch.Pool.FreeUnmanaged(ref obj);
					return true;
				}
			}
			Debug.LogWarning("Failed to find dismount position for player :" + player.displayName + " / " + player.userID.Get() + " on obj : " + base.gameObject.name);
			res = player.transform.position;
			Facepunch.Pool.FreeUnmanaged(ref obj);
			return false;
		}
	}

	public BaseMountable SpawnMountPoint(MountPointInfo mountToSpawn, Model model)
	{
		if (mountToSpawn.mountable != null)
		{
			return mountToSpawn.mountable;
		}
		Vector3 vector = Quaternion.Euler(mountToSpawn.rot) * Vector3.forward;
		Vector3 pos = mountToSpawn.pos;
		Vector3 up = Vector3.up;
		if (mountToSpawn.bone != "")
		{
			pos = model.FindBone(mountToSpawn.bone).transform.position + base.transform.TransformDirection(mountToSpawn.pos);
			vector = base.transform.TransformDirection(vector);
			up = base.transform.up;
		}
		BaseEntity baseEntity = GameManager.server.CreateEntity(mountToSpawn.prefab.resourcePath, pos, Quaternion.LookRotation(vector, up));
		BaseMountable baseMountable = baseEntity as BaseMountable;
		if (baseMountable != null)
		{
			if (enableSaving != baseMountable.enableSaving)
			{
				baseMountable.EnableSaving(enableSaving);
			}
			if (mountToSpawn.bone != "")
			{
				baseMountable.SetParent(this, mountToSpawn.bone, worldPositionStays: true, sendImmediate: true);
			}
			else
			{
				baseMountable.SetParent(this);
			}
			baseMountable.Spawn();
			mountToSpawn.mountable = baseMountable;
		}
		else
		{
			Debug.LogError("MountPointInfo prefab is not a BaseMountable. Cannot spawn mount point.");
			if (baseEntity != null)
			{
				baseEntity.Kill();
			}
		}
		return baseMountable;
	}

	[RPC_Server.MaxDistance(5f)]
	[RPC_Server]
	public void RPC_WantsPush(RPCMessage msg)
	{
		BasePlayer player = msg.player;
		if (!player.isMounted && !RecentlyPushed && CanPushNow(player) && !(rigidBody == null) && (!OnlyOwnerAccessible() || !(player != creatorEntity)) && Interface.CallHook("OnVehiclePush", this, msg.player) == null)
		{
			player.metabolism.calories.Subtract(3f);
			player.metabolism.SendChanges();
			if (rigidBody.IsSleeping())
			{
				rigidBody.WakeUp();
			}
			DoPushAction(player);
			timeSinceLastPush = 0f;
		}
	}

	public virtual void DoPushAction(BasePlayer player)
	{
		if (rigidBody == null)
		{
			return;
		}
		if (IsFlipped())
		{
			float num = rigidBody.mass * 9f;
			Vector3 torque = Vector3.forward * num;
			if (Vector3.Dot(base.transform.InverseTransformVector(base.transform.position - player.transform.position), Vector3.right) > 0f)
			{
				torque *= -1f;
			}
			if (base.transform.up.y < 0f)
			{
				torque *= -1f;
			}
			rigidBody.AddRelativeTorque(torque, ForceMode.Impulse);
		}
		else
		{
			Vector3 normalized = Vector3.ProjectOnPlane(base.transform.position - player.eyes.position, base.transform.up).normalized;
			float pushActionForce = GetPushActionForce();
			rigidBody.AddForce(normalized * pushActionForce, ForceMode.Impulse);
		}
	}

	protected virtual float GetPushActionForce()
	{
		return rigidBody.mass * 5f;
	}

	protected virtual void OnServerWake()
	{
	}

	protected virtual void OnServerSleep()
	{
	}

	public virtual bool ShouldDisableTransferProtectionOnLoad(BasePlayer player)
	{
		return true;
	}

	public override void DisableTransferProtection()
	{
		base.DisableTransferProtection();
		foreach (MountPointInfo allMountPoint in allMountPoints)
		{
			if (!(allMountPoint.mountable == null) && allMountPoint.mountable.IsTransferProtected())
			{
				allMountPoint.mountable.DisableTransferProtection();
			}
		}
	}

	public virtual void OnMountedPlayerWeightChanged(BasePlayer player)
	{
	}

	public void DisableMountedSyncForAllSeats()
	{
		foreach (MountPointInfo mountPoint in mountPoints)
		{
			BaseMountable mountable = mountPoint.mountable;
			if (!(mountable == null))
			{
				mountable.DisableMountedPlayerSync();
			}
		}
	}

	public void EnableMountedSyncForAllSeats()
	{
		foreach (MountPointInfo mountPoint in mountPoints)
		{
			BaseMountable mountable = mountPoint.mountable;
			if (!(mountable == null))
			{
				mountable.EnableMountedPlayerSync();
			}
		}
	}

	[PoolAnalyzerNonCaching]
	public static void GetPassengersForVehicle(BaseEntity entity, List<BasePlayer> passengers)
	{
		if (entity is BaseBoat baseBoat)
		{
			baseBoat.GetPlayersOnBoat(passengers);
			return;
		}
		if (entity is BaseVehicle baseVehicle)
		{
			baseVehicle.GetMountedPlayers(passengers);
		}
		foreach (BaseEntity child in entity.children)
		{
			if (child is BasePlayer basePlayer && basePlayer.IsNonNpcPlayer() && !passengers.Contains(basePlayer))
			{
				passengers.Add(basePlayer);
			}
		}
	}

	public bool IsStationary()
	{
		return HasFlag(Flags.Reserved7);
	}

	public bool IsMoving()
	{
		return !HasFlag(Flags.Reserved7);
	}

	public virtual bool IsAuthedForBuilding(BasePlayer player)
	{
		VehiclePrivilege childPrivilege = GetChildPrivilege();
		if (childPrivilege != null)
		{
			return childPrivilege.IsAuthed(player);
		}
		return false;
	}

	public virtual VehiclePrivilege GetChildPrivilege()
	{
		foreach (BaseEntity child in children)
		{
			VehiclePrivilege vehiclePrivilege = child as VehiclePrivilege;
			if (!(vehiclePrivilege == null))
			{
				return vehiclePrivilege;
			}
		}
		return null;
	}

	public override bool AnyMounted()
	{
		return HasFlag(Flags.InUse);
	}

	public override bool PlayerIsMounted(BasePlayer player)
	{
		if (player.IsValid())
		{
			return player.GetMountedVehicle() == this;
		}
		return false;
	}

	public virtual bool CanPushNow(BasePlayer pusher)
	{
		return !IsOn();
	}

	public bool HasMountPoints()
	{
		if (mountPoints.Count > 0)
		{
			return true;
		}
		using (Enumerator enumerator = allMountPoints.GetEnumerator())
		{
			if (enumerator.MoveNext())
			{
				_ = enumerator.Current;
				return true;
			}
		}
		return false;
	}

	public bool IsDriver(BasePlayer player)
	{
		if (player == null)
		{
			return false;
		}
		if (!HasMountPoints())
		{
			BasePlayer mounted = GetMounted();
			if (mounted != null)
			{
				return mounted == player;
			}
			return false;
		}
		if (base.isServer)
		{
			foreach (MountPointInfo allMountPoint in allMountPoints)
			{
				if (allMountPoint != null && !(allMountPoint.mountable == null) && allMountPoint.isDriver && allMountPoint.mountable.GetMounted() == player)
				{
					return true;
				}
			}
		}
		return false;
	}

	public override bool CanBeLooted(BasePlayer player)
	{
		if (IsAlive() && !base.IsDestroyed)
		{
			return player != null;
		}
		return false;
	}

	public bool IsFlipping()
	{
		if (IsFlipped())
		{
			return false;
		}
		bool flag = false;
		if (rigidBody != null)
		{
			Vector3 angularVelocity = rigidBody.angularVelocity;
			flag = angularVelocity.x > 0.5f || angularVelocity.z > 0.5f;
		}
		float num = Vector3.Dot(Vector3.up, base.transform.up);
		return flag || num <= 0.4f;
	}

	public bool IsFlipped()
	{
		return Vector3.Dot(Vector3.up, base.transform.up) <= 0.175f;
	}

	public virtual bool IsVehicleRoot()
	{
		return true;
	}

	public override void ResetState()
	{
		base.ResetState();
	}

	public override bool DirectlyMountable()
	{
		return IsVehicleRoot();
	}

	public override BaseVehicle VehicleParent()
	{
		return null;
	}

	protected override void OnChildAdded(BaseEntity child)
	{
		base.OnChildAdded(child);
		if (!IsDead() && !base.IsDestroyed && child is BaseVehicle baseVehicle && !baseVehicle.IsVehicleRoot() && !childVehicles.Contains(baseVehicle))
		{
			childVehicles.Add(baseVehicle);
		}
	}

	protected override void OnChildRemoved(BaseEntity child)
	{
		base.OnChildRemoved(child);
		if (child is BaseVehicle baseVehicle && !baseVehicle.IsVehicleRoot())
		{
			childVehicles.Remove(baseVehicle);
		}
	}

	public MountPointInfo GetMountPoint(int index)
	{
		if (index < 0)
		{
			return null;
		}
		if (index < mountPoints.Count)
		{
			return mountPoints[index];
		}
		index -= mountPoints.Count;
		int num = 0;
		foreach (BaseVehicle childVehicle in childVehicles)
		{
			if (childVehicle == null)
			{
				continue;
			}
			foreach (MountPointInfo allMountPoint in childVehicle.allMountPoints)
			{
				if (num == index)
				{
					return allMountPoint;
				}
				num++;
			}
		}
		return null;
	}

	public override float GetSpeed()
	{
		if (IsStationary())
		{
			return 0f;
		}
		return base.GetSpeed();
	}

	public override float PenetrationResistance(HitInfo info)
	{
		if (info != null && info.ProjectilePrefab != null && info.ProjectilePrefab.penetratesVehicles)
		{
			return 0.5f;
		}
		return base.PenetrationResistance(info);
	}
}
