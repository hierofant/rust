public class AggressionTimerEventUI : BaseEventUI
{
}
