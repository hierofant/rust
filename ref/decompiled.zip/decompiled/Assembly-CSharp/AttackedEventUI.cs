public class AttackedEventUI : BaseEventUI
{
}
