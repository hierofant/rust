public class BoatBuildingNetting : BaseMonoBehaviour
{
}
