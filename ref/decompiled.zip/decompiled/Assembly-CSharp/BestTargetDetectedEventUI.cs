public class BestTargetDetectedEventUI : BaseEventUI
{
}
