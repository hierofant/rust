using UnityEngine;

public class BeehiveLootPanel : LootPanel
{
	[Header("Info Bars")]
	public InfoBar Indoors;

	public InfoBar Humidity;

	public InfoBar Temperature;

	public InfoBar Overall;

	[Header("Grids")]
	public LootGrid LootGrid_Input;

	public LootGrid LootGrid_Output;

	[Header("Status")]
	public StatusPanel status;

	public static readonly Translate.Phrase YesIndoors = new Translate.Phrase("beehive.indoors.yes", "YES");

	public static readonly Translate.Phrase NoIndoors = new Translate.Phrase("beehive.indoors.no", "NO");
}
