#define UNITY_ASSERTIONS
using System;
using System.Collections.Generic;
using ConVar;
using Facepunch;
using Facepunch.Extend;
using Network;
using Oxide.Core;
using ProtoBuf;
using Rust;
using UnityEngine;
using UnityEngine.Assertions;

public class Catapult : BaseSiegeWeapon
{
	[Serializable]
	private struct Ammo
	{
		public ItemDefinition item;

		public GameObject go;
	}

	[Serializable]
	private struct FiringEffect
	{
		public ItemDefinition item;

		public GameObjectRef effectPrefab;
	}

	private static ItemDefinition _boulderItemDef;

	private Item loadedAmmoItem;

	private readonly float progressTickRate = 0.1f;

	[Header("Catapult")]
	[SerializeField]
	private Animator animator;

	[SerializeField]
	private Transform muzzle;

	[SerializeField]
	private float reloadTime = 6f;

	[SerializeField]
	private Ammo[] ammoPrefabs;

	[SerializeField]
	private GameObject ammoParent;

	[HideInInspector]
	public float reloadProgress;

	private const AmmoTypes ammoType = AmmoTypes.CATAPULT_BOULDER;

	[SerializeField]
	private CatapultAmmoContainer ammoStoragePrefab;

	private EntityRef<CatapultAmmoContainer> ammoStorageRef;

	private const Flags Flag_Reloading = Flags.Reserved4;

	private const Flags Flag_Loaded = Flags.Unused23;

	private BasePlayer reloadingPlayer;

	private ItemDefinition loadedAmmoDef;

	private TimeSince timeSinceLastFire;

	[SerializeField]
	[Header("Effects")]
	public GameObjectRef dryFireEffectPrefab;

	[SerializeField]
	private FiringEffect[] fireEffects;

	public static ItemDefinition BoulderItemDef
	{
		get
		{
			if (_boulderItemDef == null)
			{
				_boulderItemDef = ItemManager.FindItemDefinition("catapult.ammo.boulder");
			}
			return _boulderItemDef;
		}
	}

	public override float DriveWheelVelocity { get; }

	public override bool OnRpcMessage(BasePlayer player, uint rpc, Message msg)
	{
		using (TimeWarning.New("Catapult.OnRpcMessage"))
		{
			if (rpc == 1188838966 && player != null)
			{
				Assert.IsTrue(player.isServer, "SV_RPC Message is using a clientside player!");
				if (ConVar.Global.developer > 2)
				{
					Debug.Log("SV_RPCMessage: " + player?.ToString() + " - SERVER_CancelReload");
				}
				using (TimeWarning.New("SERVER_CancelReload"))
				{
					using (TimeWarning.New("Conditions"))
					{
						if (!RPC_Server.CallsPerSecond.Test(1188838966u, "SERVER_CancelReload", this, player, 3uL))
						{
							return true;
						}
						if (!RPC_Server.IsVisible.Test(1188838966u, "SERVER_CancelReload", this, player, 3f))
						{
							return true;
						}
						if (!RPC_Server.MaxDistance.Test(1188838966u, "SERVER_CancelReload", this, player, 3f))
						{
							return true;
						}
					}
					try
					{
						using (TimeWarning.New("Call"))
						{
							RPCMessage rPCMessage = default(RPCMessage);
							rPCMessage.connection = msg.connection;
							rPCMessage.player = player;
							rPCMessage.read = msg.read;
							RPCMessage msg2 = rPCMessage;
							SERVER_CancelReload(msg2);
						}
					}
					catch (Exception exception)
					{
						Debug.LogException(exception);
						player.Kick("RPC Error in SERVER_CancelReload");
					}
				}
				return true;
			}
			if (rpc == 3952894422u && player != null)
			{
				Assert.IsTrue(player.isServer, "SV_RPC Message is using a clientside player!");
				if (ConVar.Global.developer > 2)
				{
					Debug.Log("SV_RPCMessage: " + player?.ToString() + " - SERVER_OpenAmmo");
				}
				using (TimeWarning.New("SERVER_OpenAmmo"))
				{
					using (TimeWarning.New("Conditions"))
					{
						if (!RPC_Server.IsVisible.Test(3952894422u, "SERVER_OpenAmmo", this, player, 3f))
						{
							return true;
						}
					}
					try
					{
						using (TimeWarning.New("Call"))
						{
							RPCMessage rPCMessage = default(RPCMessage);
							rPCMessage.connection = msg.connection;
							rPCMessage.player = player;
							rPCMessage.read = msg.read;
							RPCMessage msg3 = rPCMessage;
							SERVER_OpenAmmo(msg3);
						}
					}
					catch (Exception exception2)
					{
						Debug.LogException(exception2);
						player.Kick("RPC Error in SERVER_OpenAmmo");
					}
				}
				return true;
			}
			if (rpc == 2817383917u && player != null)
			{
				Assert.IsTrue(player.isServer, "SV_RPC Message is using a clientside player!");
				if (ConVar.Global.developer > 2)
				{
					Debug.Log("SV_RPCMessage: " + player?.ToString() + " - SERVER_ReloadStart");
				}
				using (TimeWarning.New("SERVER_ReloadStart"))
				{
					using (TimeWarning.New("Conditions"))
					{
						if (!RPC_Server.CallsPerSecond.Test(2817383917u, "SERVER_ReloadStart", this, player, 3uL))
						{
							return true;
						}
						if (!RPC_Server.IsVisible.Test(2817383917u, "SERVER_ReloadStart", this, player, 3f))
						{
							return true;
						}
						if (!RPC_Server.MaxDistance.Test(2817383917u, "SERVER_ReloadStart", this, player, 3f))
						{
							return true;
						}
					}
					try
					{
						using (TimeWarning.New("Call"))
						{
							RPCMessage rPCMessage = default(RPCMessage);
							rPCMessage.connection = msg.connection;
							rPCMessage.player = player;
							rPCMessage.read = msg.read;
							RPCMessage msg4 = rPCMessage;
							SERVER_ReloadStart(msg4);
						}
					}
					catch (Exception exception3)
					{
						Debug.LogException(exception3);
						player.Kick("RPC Error in SERVER_ReloadStart");
					}
				}
				return true;
			}
			if (rpc == 4172853352u && player != null)
			{
				Assert.IsTrue(player.isServer, "SV_RPC Message is using a clientside player!");
				if (ConVar.Global.developer > 2)
				{
					Debug.Log("SV_RPCMessage: " + player?.ToString() + " - SERVER_WantsFire");
				}
				using (TimeWarning.New("SERVER_WantsFire"))
				{
					using (TimeWarning.New("Conditions"))
					{
						if (!RPC_Server.MaxDistance.Test(4172853352u, "SERVER_WantsFire", this, player, 3f))
						{
							return true;
						}
					}
					try
					{
						using (TimeWarning.New("Call"))
						{
							RPCMessage rPCMessage = default(RPCMessage);
							rPCMessage.connection = msg.connection;
							rPCMessage.player = player;
							rPCMessage.read = msg.read;
							RPCMessage msg5 = rPCMessage;
							SERVER_WantsFire(msg5);
						}
					}
					catch (Exception exception4)
					{
						Debug.LogException(exception4);
						player.Kick("RPC Error in SERVER_WantsFire");
					}
				}
				return true;
			}
		}
		return base.OnRpcMessage(player, rpc, msg);
	}

	public override void ServerInit()
	{
		base.ServerInit();
		ammoStorageRef.Set(ammoStoragePrefab);
	}

	public void UpdateLoadedAmmo(Item item, bool added)
	{
		loadedAmmoItem = (added ? item : null);
		loadedAmmoDef = (added ? item.info : null);
		SetFlagLocal(Flags.Unused23, loadedAmmoDef != null);
		SendNetworkUpdateImmediate();
	}

	public bool Fire(BasePlayer shooter, float force)
	{
		FireRecoil();
		float num = Mathf.Lerp(2f, 1f, Mathf.Clamp01(force));
		float num2 = Mathf.Lerp(0.5f, 1f, Mathf.Clamp01(force));
		bool flag = true;
		Vector3 firingPos = muzzle.position;
		BasePlayer passenger = GetPassenger();
		object obj = Interface.CallHook("OnCatapultFireForce", this, shooter, num2);
		if (obj is float)
		{
			num2 = (float)obj;
		}
		if (passenger != null)
		{
			passenger.ServerPosition = muzzle.transform.position;
			passenger.Ragdoll(muzzle.transform.forward * (20f * num2) + Vector3.up * (2.5f * num), matchPlayerGravity: false, flailInAir: true, dieOnImpact: true, this);
			return true;
		}
		if (GamePhysics.CheckSphere(muzzle.position, 1f, 1236994833, QueryTriggerInteraction.Ignore))
		{
			Vector3 vector = base.transform.position + Vector3.up * 2f;
			if (GamePhysics.Trace(new Ray(vector, muzzle.position - vector), 0f, out var hitInfo, 10f, 1236994833, QueryTriggerInteraction.Ignore))
			{
				flag = false;
				firingPos = hitInfo.point - Vector3.up;
			}
		}
		ServerProjectile projectile2;
		if (loadedAmmoDef == BoulderItemDef)
		{
			ItemModCatapultBoulder component = loadedAmmoDef.GetComponent<ItemModCatapultBoulder>();
			if (component == null)
			{
				return false;
			}
			foreach (ItemModCatapultBoulder.ProjectileSettings projectileSetting in component.projectileSettings)
			{
				for (int i = 0; i < projectileSetting.count; i++)
				{
					Vector3 forward = muzzle.forward;
					forward = Quaternion.Euler(UnityEngine.Random.Range(0f - component.spreadAngle, component.spreadAngle), UnityEngine.Random.Range(0f - component.spreadAngle, component.spreadAngle), 0f) * forward;
					if (FireProjectile(projectileSetting.prefab, firingPos, forward, shooter, 0.25f, 30f * num2, out var projectile))
					{
						if (!flag)
						{
							projectile.GetComponent<TimedExplosive>()?.ForceExplode();
						}
						projectile.ignoreEntity = this;
						projectile.gravityModifier *= num * UnityEngine.Random.Range(1f - projectileSetting.gravityModifier, 1f + projectileSetting.gravityModifier);
						shooter.MarkHostileFor();
					}
				}
			}
			loadedAmmoItem.UseItem();
		}
		else if (TryFireProjectile(ammoStorageRef.Get(base.isServer), AmmoTypes.CATAPULT_BOULDER, firingPos, muzzle.forward, shooter, 0.25f, 30f * num2, out projectile2))
		{
			projectile2.ignoreEntity = this;
			if (!flag)
			{
				projectile2.GetComponent<TimedExplosive>()?.ForceExplode();
			}
			projectile2.gravityModifier *= num;
			shooter.MarkHostileFor();
			return true;
		}
		return false;
	}

	[RPC_Server]
	[RPC_Server.MaxDistance(3f)]
	public void SERVER_WantsFire(RPCMessage msg)
	{
		BasePlayer player = msg.player;
		if (CanFire() && Interface.CallHook("OnSiegeWeaponFire", this, player) == null)
		{
			float force = reloadProgress;
			Fire(player, force);
			reloadProgress = 0f;
			timeSinceLastFire = 0f;
			FireAnimation();
			GameObjectRef loadedAmmoFiringEffect = GetLoadedAmmoFiringEffect();
			if (loadedAmmoFiringEffect != null && loadedAmmoFiringEffect.isValid)
			{
				Effect.server.Run(loadedAmmoFiringEffect.resourcePath, this, 0u, Vector3.zero, Vector3.up, null, broadcast: true);
			}
			RefreshLastUseTime();
			ClientRPC(RpcTarget.NetworkGroup("CLIENT_Fire"));
		}
	}

	public override void AttemptMount(BasePlayer player, bool doMountChecks = true)
	{
		if (!HasFlag(Flags.Unused23))
		{
			base.AttemptMount(player, doMountChecks);
		}
	}

	[RPC_Server]
	[RPC_Server.IsVisible(3f)]
	public void SERVER_OpenAmmo(RPCMessage msg)
	{
		BasePlayer player = msg.player;
		if (CanBeLooted(player))
		{
			ammoStorageRef.Get(base.isServer).PlayerOpenLoot(player);
		}
	}

	public void FireRecoil()
	{
		if (!(rigidBody == null))
		{
			if (rigidBody.IsSleeping())
			{
				rigidBody.WakeUp();
			}
			Vector3 normalized = Vector3.ProjectOnPlane(base.transform.forward, base.transform.up).normalized;
			rigidBody.AddForce(normalized * rigidBody.mass * (carPhysics.HasHandbrake() ? 5f : 1f), ForceMode.Impulse);
			rigidBody.AddForceAtPosition(Vector3.up * rigidBody.mass * 1.5f, centreOfMassTransform.position + base.transform.forward * 1f, ForceMode.Impulse);
		}
	}

	[RPC_Server.CallsPerSecond(3uL)]
	[RPC_Server.IsVisible(3f)]
	[RPC_Server]
	[RPC_Server.MaxDistance(3f)]
	private void SERVER_ReloadStart(RPCMessage msg)
	{
		if (msg.player.CanInteract() && CanReload())
		{
			using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
			{
				flagsUpdateScope.Set(Flags.Reserved4, b: true);
			}
			RefreshLastUseTime();
			reloadingPlayer = msg.player;
			InvokeRepeating(ReloadProgress, 0f, progressTickRate);
		}
	}

	[RPC_Server.CallsPerSecond(3uL)]
	[RPC_Server.IsVisible(3f)]
	[RPC_Server.MaxDistance(3f)]
	[RPC_Server]
	public void SERVER_CancelReload(RPCMessage msg)
	{
		if (msg.player == reloadingPlayer)
		{
			StopPlayerReload();
		}
	}

	private void ReloadProgress()
	{
		if (reloadingPlayer == null || reloadingPlayer.IsDead() || reloadingPlayer.IsSleeping() || Vector3Ex.Distance2D(reloadingPlayer.transform.position, base.transform.position) > 5f)
		{
			StopPlayerReload();
			return;
		}
		reloadProgress += progressTickRate / reloadTime;
		animator.SetFloat("Reload", reloadProgress);
		if (reloadProgress >= 1f)
		{
			reloadProgress = 1f;
			StopPlayerReload();
		}
		SendNetworkUpdate();
	}

	public void AdminReload(int ammo)
	{
		foreach (MountPointInfo allMountPoint in base.allMountPoints)
		{
			BasePlayer mounted = allMountPoint.mountable.GetMounted();
			if (mounted != null && !mounted.IsBot)
			{
				return;
			}
		}
		using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
		{
			flagsUpdateScope.Set(Flags.Reserved4, b: true);
		}
		reloadProgress = 1f;
		animator.SetFloat("Reload", reloadProgress);
		switch (ammo)
		{
		case 5:
			ammoStorageRef.Get(base.isServer).inventory.Clear();
			SpawnAndMountBotPlayer();
			break;
		default:
		{
			ammoStorageRef.Get(base.isServer).inventory.Clear();
			foreach (MountPointInfo allMountPoint2 in base.allMountPoints)
			{
				BasePlayer mounted2 = allMountPoint2.mountable.GetMounted();
				if (mounted2 != null && mounted2.IsBot)
				{
					mounted2.EnsureDismounted();
					mounted2.Kill();
				}
			}
			ItemDefinition itemToCreate = null;
			switch (ammo)
			{
			case 1:
				itemToCreate = ItemManager.FindItemDefinition("catapult.ammo.boulder");
				break;
			case 2:
				itemToCreate = ItemManager.FindItemDefinition("catapult.ammo.incendiary");
				break;
			case 3:
				itemToCreate = ItemManager.FindItemDefinition("catapult.ammo.explosive");
				break;
			case 4:
				itemToCreate = ItemManager.FindItemDefinition("catapult.ammo.bee");
				break;
			}
			ammoStorageRef.Get(base.isServer).inventory.AddItem(itemToCreate, 1, 0uL);
			break;
		}
		case 0:
			break;
		}
		SendNetworkUpdateImmediate();
		Invoke(StopPlayerReload, 0.5f);
	}

	private void SpawnAndMountBotPlayer()
	{
		foreach (MountPointInfo allMountPoint in base.allMountPoints)
		{
			BasePlayer basePlayer = GameManager.server.CreateEntity("assets/prefabs/player/player.prefab") as BasePlayer;
			basePlayer.Spawn();
			allMountPoint.mountable.AttemptMount(basePlayer, doMountChecks: false);
			if (!basePlayer.isMounted)
			{
				basePlayer.Kill();
			}
			else
			{
				basePlayer.UpdateNetworkGroup();
			}
		}
	}

	public void StopPlayerReload()
	{
		CancelInvoke(ReloadProgress);
		using (FlagsUpdateScope flagsUpdateScope = StartSetFlags(FlagsUpdateMode.SendNetworkUpdate))
		{
			flagsUpdateScope.Set(Flags.Reserved4, b: false);
		}
		reloadingPlayer = null;
	}

	public override void OnTowAttach()
	{
		base.OnTowAttach();
	}

	public override void OnTowDetach()
	{
		base.OnTowDetach();
	}

	public override void OnEngineStartFailed()
	{
	}

	public override bool MeetsEngineRequirements()
	{
		return false;
	}

	private GameObjectRef GetLoadedAmmoFiringEffect()
	{
		if (loadedAmmoDef == null)
		{
			return dryFireEffectPrefab;
		}
		FiringEffect firingEffect = ((IReadOnlyCollection<FiringEffect>)(object)fireEffects).FindWith((FiringEffect x) => x.item, loadedAmmoDef);
		if (firingEffect.effectPrefab != null && firingEffect.effectPrefab.isValid)
		{
			return firingEffect.effectPrefab;
		}
		return null;
	}

	[ServerVar(Help = "Reload all catapults. 0: empty, 1: stone boulder, 2: fire bomb, 3: propane explosive, 4: bee bomb, 5: bot player")]
	public static void reload(ConsoleSystem.Arg arg)
	{
		BasePlayer basePlayer = ArgEx.Player(arg);
		if (basePlayer == null)
		{
			arg.ReplyWith("Null player.");
		}
		else
		{
			if (!basePlayer.IsAdmin)
			{
				return;
			}
			int @int = arg.GetInt(0, 1);
			@int = Mathf.Clamp(@int, 0, 5);
			Catapult[] array = Util.FindAll<Catapult>();
			int num = 0;
			Catapult[] array2 = array;
			foreach (Catapult catapult in array2)
			{
				if (catapult.isServer && Vector3.Distance(catapult.transform.position, basePlayer.transform.position) <= 100f)
				{
					catapult.AdminReload(@int);
					num++;
				}
			}
			arg.ReplyWith($"Reloaded {num} catapults.");
		}
	}

	[ServerVar(Help = "Fire all catapults")]
	public static void fire(ConsoleSystem.Arg arg)
	{
		BasePlayer basePlayer = ArgEx.Player(arg);
		if (basePlayer == null)
		{
			arg.ReplyWith("Null player.");
		}
		else
		{
			if (!basePlayer.IsAdmin)
			{
				return;
			}
			Catapult[] array = Util.FindAll<Catapult>();
			foreach (Catapult catapult in array)
			{
				if (catapult.isServer && Vector3.Distance(catapult.transform.position, basePlayer.transform.position) <= 100f)
				{
					RPCMessage rPCMessage = default(RPCMessage);
					rPCMessage.player = basePlayer;
					RPCMessage msg = rPCMessage;
					catapult.SERVER_WantsFire(msg);
				}
			}
		}
	}

	public override void Save(SaveInfo info)
	{
		base.Save(info);
		info.msg.catapult = Facepunch.Pool.Get<ProtoBuf.Catapult>();
		info.msg.catapult.ammoStorageID = ammoStorageRef.uid;
		info.msg.catapult.reloadProgress = reloadProgress;
		info.msg.catapult.ammoType = ((loadedAmmoItem != null) ? loadedAmmoDef.itemid : 0);
	}

	public override void Load(LoadInfo info)
	{
		base.Load(info);
		if (info.msg.catapult != null)
		{
			ammoStorageRef.uid = info.msg.catapult.ammoStorageID;
			reloadProgress = info.msg.catapult.reloadProgress;
			_ = loadedAmmoDef;
			loadedAmmoDef = ItemManager.FindItemDefinition(info.msg.catapult.ammoType);
		}
	}

	public override void InitShared()
	{
		base.InitShared();
		Invoke(delegate
		{
			animator.SetFloat("Reload", reloadProgress);
		}, 0.25f);
	}

	protected override void CreateEngineController()
	{
	}

	protected override void OnChildAdded(BaseEntity child)
	{
		base.OnChildAdded(child);
		if (child.prefabID == ammoStoragePrefab.GetEntity().prefabID)
		{
			CatapultAmmoContainer catapultAmmoContainer = (CatapultAmmoContainer)child;
			ammoStorageRef.Set(catapultAmmoContainer);
			catapultAmmoContainer.catapult = this;
		}
	}

	public bool IsArmed()
	{
		return reloadProgress >= 0.4f;
	}

	public bool IsReloading()
	{
		return HasFlag(Flags.Reserved4);
	}

	public bool CanReload()
	{
		if (!IsReloading() && !HasFlag(Flags.Reserved12) && reloadProgress != 1f)
		{
			return !IsWaterlogged();
		}
		return false;
	}

	public bool CanFire()
	{
		if (IsArmed() && !IsReloading())
		{
			return !IsWaterlogged();
		}
		return false;
	}

	protected override bool CanPushNow(BasePlayer pusher)
	{
		if (base.CanPushNow(pusher))
		{
			return (float)timeSinceLastFire > 2f;
		}
		return false;
	}

	private void FireAnimation()
	{
		animator.ResetTrigger("Fire");
		animator.SetTrigger("Fire");
		Invoke(delegate
		{
			reloadProgress = 0f;
			animator.SetFloat("Reload", reloadProgress);
		}, 0.5f);
	}

	public override bool CanBeLooted(BasePlayer player)
	{
		if (!HasFlag(Flags.Reserved11))
		{
			return base.CanBeLooted(player);
		}
		return false;
	}
}
