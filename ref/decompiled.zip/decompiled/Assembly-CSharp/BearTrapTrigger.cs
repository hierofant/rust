public class BearTrapTrigger : BaseTrapTrigger
{
}
