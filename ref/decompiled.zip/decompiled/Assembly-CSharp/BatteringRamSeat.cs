public class BatteringRamSeat : BaseVehicleSeat
{
}
