public class BanditGuard : HumanNPC
{
}
