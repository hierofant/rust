public class BaseFuelLightSource : BaseOven
{
}
