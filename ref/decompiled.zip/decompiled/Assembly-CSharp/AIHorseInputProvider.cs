using UnityEngine;

public class AIHorseInputProvider : IHorseInputProvider
{
	private Transform playerTransform;

	private RidableHorse horse;

	private float followSpeed;

	private float stoppingDistance;

	private float turnChangeCooldown = 0.3f;

	private float turnCooldownTimer;

	private float currentSteerInput;

	public AIHorseInputProvider(RidableHorse horse, Transform playerTransform, float stoppingDistance)
	{
		this.horse = horse;
		this.playerTransform = playerTransform;
		this.stoppingDistance = stoppingDistance;
	}

	public float GetMoveInput()
	{
		Vector3 vector = playerTransform.position - horse.transform.position;
		vector.y = 0f;
		float magnitude = vector.magnitude;
		if (horse.GetSpeed() > 2f)
		{
			return -1f;
		}
		if (magnitude > stoppingDistance)
		{
			return Mathf.Clamp(horse.transform.InverseTransformDirection(vector.normalized).z, 0f, 1f);
		}
		return 0f;
	}

	public float GetSteerInput()
	{
		Vector3 forward = playerTransform.position - horse.transform.position;
		forward.y = 0f;
		if (forward.magnitude > stoppingDistance - 2f)
		{
			Vector3 vector = Vector3.Cross(horse.transform.forward, forward.normalized);
			int num = 0;
			if (vector.y > 0.4f)
			{
				num = 1;
			}
			else if (vector.y < -0.4f)
			{
				num = -1;
			}
			Quaternion b = Quaternion.LookRotation(forward);
			float num2 = Quaternion.Angle(horse.transform.rotation, b);
			if (num2 > 160f && num2 < 180f)
			{
				num = -1;
			}
			if ((float)num != currentSteerInput && turnCooldownTimer <= 0f)
			{
				currentSteerInput = num;
				turnCooldownTimer = turnChangeCooldown;
			}
		}
		else if (currentSteerInput != 0f && turnCooldownTimer <= 0f)
		{
			currentSteerInput = 0f;
			turnCooldownTimer = turnChangeCooldown;
		}
		if (turnCooldownTimer > 0f)
		{
			turnCooldownTimer -= Time.fixedDeltaTime;
		}
		return currentSteerInput;
	}
}
