using System;
using System.Collections.Generic;
using Facepunch;
using Network;
using ProtoBuf;
using Rust;
using UnityEngine;

public class AttackHelicopterRockets : StorageContainer
{
	[SerializeField]
	private Transform[] rocketMuzzlePositions;

	[SerializeField]
	private GameObjectRef rocketFireTubeFX;

	[SerializeField]
	public float timeBetweenRockets = 0.5f;

	[SerializeField]
	private float timeBetweenFlares = 30f;

	[SerializeField]
	public float reloadTime = 8f;

	[SerializeField]
	public int rocketsPerReload = 6;

	[SerializeField]
	public ItemDefinition incendiaryRocketDef;

	[SerializeField]
	public ItemDefinition hvRocketDef;

	[SerializeField]
	private ItemDefinition flareItemDef;

	[NonSerialized]
	public AttackHelicopter owner;

	private const AmmoTypes ammoType = AmmoTypes.ROCKET;

	public TimeSince timeSinceRocketFired;

	private TimeSince timeSinceFlareFired;

	[NonSerialized]
	public AttackHelicopter.PreferredRocketType preferredRocketType;

	private const float ROCKET_LAUNCH_OFFSET = 1f;

	private int rocketsSinceReload;

	private ItemDefinition currAmmoDef;

	private bool leftSide;

	public bool CanFireRocket
	{
		get
		{
			if (!IsReloading && (float)timeSinceRocketFired >= timeBetweenRockets)
			{
				return GetRocketAmount() > 0;
			}
			return false;
		}
	}

	public bool IsReloading
	{
		get
		{
			if (rocketsSinceReload >= rocketsPerReload && (float)timeSinceRocketFired < reloadTime)
			{
				return GetRocketAmount() > 0;
			}
			return false;
		}
	}

	public bool CanFireFlare
	{
		get
		{
			if ((float)timeSinceFlareFired >= timeBetweenFlares)
			{
				return HasFlareAmmo();
			}
			return false;
		}
	}

	private bool HasOwner => owner != null;

	public override bool OnRpcMessage(BasePlayer player, uint rpc, Message msg)
	{
		using (TimeWarning.New("AttackHelicopterRockets.OnRpcMessage"))
		{
		}
		return base.OnRpcMessage(player, rpc, msg);
	}

	public override void InitShared()
	{
		base.InitShared();
		ResetFiringTimes();
	}

	public override void ServerInit()
	{
		base.ServerInit();
		TryGetAmmoDef(out currAmmoDef);
	}

	public int GetRocketAmount()
	{
		if (base.isServer)
		{
			if (preferredRocketType == AttackHelicopter.PreferredRocketType.HV)
			{
				return base.inventory.GetAmmoAmount(hvRocketDef);
			}
			if (preferredRocketType == AttackHelicopter.PreferredRocketType.Incendiary)
			{
				return base.inventory.GetAmmoAmount(incendiaryRocketDef);
			}
			return base.inventory.GetAmmoAmount(AmmoTypes.ROCKET);
		}
		return 0;
	}

	public bool HasFlareAmmo()
	{
		if (base.isServer)
		{
			return base.inventory.HasAny(flareItemDef);
		}
		return false;
	}

	public int GetAmmoBeforeReload()
	{
		int b = ((rocketsSinceReload >= rocketsPerReload) ? rocketsSinceReload : (rocketsPerReload - rocketsSinceReload));
		return Mathf.Min(GetRocketAmount(), b);
	}

	public bool TryGetAmmoDef(out ItemDefinition ammoDef)
	{
		ammoDef = null;
		if (base.isServer)
		{
			List<Item> obj = Pool.Get<List<Item>>();
			base.inventory.FindAmmo(obj, AmmoTypes.ROCKET);
			if (obj.Count > 0)
			{
				ammoDef = obj[obj.Count - 1].info;
			}
			Pool.Free(ref obj, freeElements: false);
		}
		return ammoDef != null;
	}

	public Vector3 MuzzleMidPoint()
	{
		return (rocketMuzzlePositions[1].position + rocketMuzzlePositions[0].position) * 0.5f;
	}

	public float GetMinRocketSpeed()
	{
		return owner.GetSpeed() + 2f;
	}

	public Vector3 GetProjectedHitPos()
	{
		Vector3 vector = MuzzleMidPoint() + rocketMuzzlePositions[0].forward * 1f;
		Vector3 forward = owner.transform.forward;
		if (TryGetAmmoDef(out var ammoDef))
		{
			ItemModProjectile component = ammoDef.GetComponent<ItemModProjectile>();
			ServerProjectile component2 = component.projectileObject.Get().GetComponent<ServerProjectile>();
			if (component != null && component2 != null)
			{
				float minRocketSpeed = GetMinRocketSpeed();
				float gravity = Physics.gravity.y * component2.gravityModifier;
				Vector3 lhs = component2.initialVelocity + forward * component2.speed;
				if (minRocketSpeed > 0f)
				{
					float num = Vector3.Dot(lhs, forward) - minRocketSpeed;
					if (num < 0f)
					{
						lhs += forward * (0f - num);
					}
				}
				if (Ballistics.TryGetPhysicsProjectileHitPos(vector, lhs.normalized, lhs.magnitude, gravity, out var result, 1.5f, 0.5f, 32f, owner))
				{
					return result;
				}
			}
		}
		return vector + forward * 1000f;
	}

	private void ResetFiringTimes()
	{
		timeSinceRocketFired = 9999f;
		timeSinceFlareFired = 9999f;
	}

	public override void Save(SaveInfo info)
	{
		base.Save(info);
		info.msg.attackHeliRockets = Pool.Get<AttackHeliRockets>();
		info.msg.attackHeliRockets.totalAmmo = GetRocketAmount();
		info.msg.attackHeliRockets.hasFlares = HasFlareAmmo();
		info.msg.attackHeliRockets.rocketsSinceReload = rocketsSinceReload;
		info.msg.attackHeliRockets.preferredAmmoType = (int)preferredRocketType;
		if (currAmmoDef != null)
		{
			info.msg.attackHeliRockets.ammoItemID = currAmmoDef.itemid;
		}
	}

	public override BasePlayer ToPlayer()
	{
		if (HasOwner)
		{
			return owner.GetPassenger();
		}
		return null;
	}

	public override bool ItemFilter(BasePlayer player, Item item, int targetSlot)
	{
		if (!base.ItemFilter(player, item, targetSlot))
		{
			return false;
		}
		if (targetSlot == -1)
		{
			if (IsValidFlare())
			{
				for (int i = 12; i < base.inventory.capacity; i++)
				{
					if (!base.inventory.SlotTaken(item, i))
					{
						targetSlot = i;
						break;
					}
				}
			}
			else
			{
				if (!IsValidRocket())
				{
					return false;
				}
				for (int j = 0; j < 12; j++)
				{
					if (!base.inventory.SlotTaken(item, j))
					{
						targetSlot = j;
						break;
					}
				}
			}
		}
		if (targetSlot < 12)
		{
			return IsValidRocket();
		}
		return IsValidFlare();
		bool IsValidFlare()
		{
			return item.info == flareItemDef;
		}
		bool IsValidRocket()
		{
			if (!(item.info == incendiaryRocketDef))
			{
				return item.info == hvRocketDef;
			}
			return true;
		}
	}

	public override void OnItemAddedOrRemoved(Item item, bool added)
	{
		if (added)
		{
			rocketsSinceReload = 0;
			if ((float)timeSinceFlareFired < timeBetweenFlares || (float)timeSinceRocketFired < timeBetweenRockets)
			{
				ResetFiringTimes();
				ClientRPC(RpcTarget.NetworkGroup("ResetFiringTimes"));
			}
		}
		TryGetAmmoDef(out currAmmoDef);
		SendNetworkUpdate();
	}

	public bool InputTick(AttackHelicopter.GunnerInputState input, BasePlayer gunner)
	{
		if (!owner.GunnerIsInGunnerView)
		{
			return false;
		}
		bool result = false;
		if (input.fire2)
		{
			result = TryFireRocket(gunner);
		}
		return result;
	}

	public bool TryFireRocket(BasePlayer shooter)
	{
		if (!CanFireRocket)
		{
			return false;
		}
		if (owner == null)
		{
			return false;
		}
		if (owner.InSafeZone())
		{
			return false;
		}
		int num = ((!leftSide) ? 1 : 0);
		Vector3 position = rocketMuzzlePositions[num].position;
		Vector3 forward = rocketMuzzlePositions[num].forward;
		float minRocketSpeed = GetMinRocketSpeed();
		if (owner.TryFireProjectile(this, AmmoTypes.ROCKET, position, forward, shooter, 1f, minRocketSpeed, out var _))
		{
			Effect.server.Run(rocketFireTubeFX.resourcePath, this, StringPool.Get(rocketMuzzlePositions[num].name), Vector3.zero, Vector3.zero, null, broadcast: true);
			leftSide = !leftSide;
			int arg = (TryGetAmmoDef(out currAmmoDef) ? currAmmoDef.itemid : 0);
			timeSinceRocketFired = 0f;
			if (rocketsSinceReload < rocketsPerReload)
			{
				rocketsSinceReload++;
			}
			else
			{
				rocketsSinceReload = 1;
			}
			ClientRPC(RpcTarget.NetworkGroup("RPCRocketFired"), (short)GetRocketAmount(), arg, rocketsSinceReload);
			return true;
		}
		return false;
	}

	public bool TryFireFlare()
	{
		if (!CanFireFlare)
		{
			return false;
		}
		if (owner == null)
		{
			return false;
		}
		if (!base.inventory.TryTakeOne(flareItemDef.itemid, out var item))
		{
			return false;
		}
		item.Remove();
		timeSinceFlareFired = 0f;
		owner.LaunchFlare();
		ClientRPC(RpcTarget.NetworkGroup("RPCFlareFired"), HasFlareAmmo());
		return true;
	}

	public void SetAmmoType(AttackHelicopter.PreferredRocketType type)
	{
		preferredRocketType = type;
		SendNetworkUpdate();
	}

	public void StartReload()
	{
		if (rocketsSinceReload != 0 && rocketsSinceReload != rocketsPerReload && GetRocketAmount() != 0 && !IsReloading)
		{
			rocketsSinceReload = rocketsPerReload;
			int arg = (TryGetAmmoDef(out currAmmoDef) ? currAmmoDef.itemid : 0);
			ClientRPC(RpcTarget.NetworkGroup("RPCRocketFired"), (short)GetRocketAmount(), arg, rocketsSinceReload);
			SendNetworkUpdate();
		}
	}
}
